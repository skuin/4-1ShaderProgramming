#version 440

in vec4 v_Color;

out vec4 FragColor;

void main()
{
    FragColor = v_Color;
}
